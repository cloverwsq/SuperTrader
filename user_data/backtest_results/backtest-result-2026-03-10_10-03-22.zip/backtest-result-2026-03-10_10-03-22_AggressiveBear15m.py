# pragma pylint: disable=missing-docstring, invalid-name
"""
Strategy: AggressiveBear15m  v3 — 熊市反弹做空
核心逻辑：等价格从低位反弹到 EMA 阻力位，确认拒绝后做空
- 在下跌趋势中，反弹到 EMA 是做空最佳时机（高位入场，止损紧贴阻力）
- 比破位做空胜率高：入场价在阻力位，有参考价设止损
- 1h 门控确认中期趋势向下，15m 捕捉具体反弹失败信号

入场条件：
  1h：EMA20 < EMA50（中期下行趋势）
  15m：价格反弹至 EMA21 附近 → 出现阴线拒绝 → RSI 回落 → MACD 持续负
"""

from datetime import datetime
from typing import Optional
import pandas as pd
from pandas import DataFrame

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, informative
from freqtrade.enums import CandleType
import talib.abstract as ta
from technical import qtpylib


class AggressiveBear15m(IStrategy):

    INTERFACE_VERSION: int = 3
    can_short: bool = True
    timeframe = "15m"

    # 止盈：反弹做空的目标更明确，可以持有稍长
    minimal_roi = {
        "0":    0.03,
        "120":  0.02,
        "360":  0.01,
    }

    stoploss = -0.025           # 止损设在阻力位上方，稍宽

    trailing_stop = True
    trailing_stop_positive = 0.012
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    process_only_new_candles = True
    startup_candle_count: int = 220

    use_exit_signal = True
    exit_profit_only = True     # 亏损只靠 stoploss，不乱平
    ignore_roi_if_entry_signal = False

    # ── 超参数 ──────────────────────────────────────────────────────
    ema21_period = IntParameter(15, 30, default=21, space="sell", optimize=True, load=True)
    ema50_period = IntParameter(35, 65, default=50, space="sell", optimize=True, load=True)

    rsi_period   = IntParameter(7, 21,  default=14, space="sell", optimize=True, load=True)
    rsi_bounce   = DecimalParameter(42, 62, decimals=0, default=52, space="sell", optimize=True, load=True)  # 反弹RSI高点

    vol_period   = IntParameter(10, 30, default=20, space="sell", optimize=True, load=True)

    # EMA 阻力贴近度：价格距 EMA21 多近算"触及"
    ema_touch_pct = DecimalParameter(0.001, 0.012, decimals=3, default=0.006, space="sell", optimize=True, load=True)

    gate_ema_fast = IntParameter(15, 25, default=20, space="sell", optimize=True, load=True)
    gate_ema_slow = IntParameter(40, 60, default=50, space="sell", optimize=True, load=True)

    # ── 1h 门控 ─────────────────────────────────────────────────────
    @informative("1h")
    def populate_indicators_1h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        for val in self.gate_ema_fast.range:
            dataframe[f"ema_fast_{val}"] = ta.EMA(dataframe, timeperiod=val)
        for val in self.gate_ema_slow.range:
            dataframe[f"ema_slow_{val}"] = ta.EMA(dataframe, timeperiod=val)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    # ── 15m 主指标 ──────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        for val in self.ema21_period.range:
            dataframe[f"ema21_{val}"] = ta.EMA(dataframe, timeperiod=val)
        for val in self.ema50_period.range:
            dataframe[f"ema50_{val}"] = ta.EMA(dataframe, timeperiod=val)

        for val in self.rsi_period.range:
            dataframe[f"rsi_{val}"] = ta.RSI(dataframe, timeperiod=val)

        for val in self.vol_period.range:
            dataframe[f"vol_sma_{val}"] = ta.SMA(dataframe["volume"], timeperiod=val)

        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macdhist"] = macd["macdhist"]

        # ATR（用于止损参考）
        dataframe["atr14"] = ta.ATR(dataframe, timeperiod=14)

        # 资金费率
        funding_df = self.dp.get_pair_dataframe(
            pair=metadata["pair"],
            timeframe="1h",
            candle_type=CandleType.FUNDING_RATE,
        )
        if funding_df is not None and not funding_df.empty:
            funding_df = funding_df[["date", "open"]].rename(columns={"open": "funding_rate"})
            dataframe = dataframe.merge(funding_df, on="date", how="left")
            dataframe["funding_rate"] = dataframe["funding_rate"].ffill().fillna(0)
        else:
            dataframe["funding_rate"] = 0

        return dataframe

    # ── 动态杠杆 ────────────────────────────────────────────────────
    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float,
                 entry_tag: Optional[str], side: str, **kwargs) -> float:
        # 资金费率偏高时多头更脆弱，加大杠杆
        if entry_tag and "fund" in entry_tag:
            return min(5.0, max_leverage)
        return min(3.0, max_leverage)

    # ── 入场信号 ────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        ema21_col = f"ema21_{self.ema21_period.value}"
        ema50_col = f"ema50_{self.ema50_period.value}"
        rsi_col   = f"rsi_{self.rsi_period.value}"
        vol_col   = f"vol_sma_{self.vol_period.value}"
        gf_col    = f"ema_fast_{self.gate_ema_fast.value}_1h"
        gs_col    = f"ema_slow_{self.gate_ema_slow.value}_1h"

        # ── 1h 门控：中期趋势向下 + 1h RSI 未超买 ───────────────────
        gate_bear = (
            (dataframe[gf_col] < dataframe[gs_col])
            & (dataframe["rsi_1h"] < 65)
        )

        # ── 核心：反弹触及 EMA21 后阴线拒绝 ────────────────────────
        # 价格高点触及 EMA21（或前一根刚触及）
        touched_ema = (
            (dataframe["high"] >= dataframe[ema21_col] * (1 - self.ema_touch_pct.value))
            & (dataframe["high"] <= dataframe[ema21_col] * (1 + self.ema_touch_pct.value * 3))
        )
        # 确认拒绝：当根阴线收盘在 EMA21 下方
        rejection = (
            (dataframe["close"] < dataframe[ema21_col])
            & (dataframe["close"] < dataframe["open"])   # 阴线
        )

        # ── 辅助确认 ─────────────────────────────────────────────────
        # RSI 反弹后回落（说明动量已经转向）
        rsi_pullback = (
            (dataframe[rsi_col] > self.rsi_bounce.value - 5)  # 曾经反弹过
            & (dataframe[rsi_col] < self.rsi_bounce.value + 10)  # 但没超买
        )
        # EMA50 压制：close 在 EMA50 下方（大趋势压力存在）
        below_ema50 = dataframe["close"] < dataframe[ema50_col]
        # MACD 仍然为负
        macd_neg = dataframe["macdhist"] < 0
        # 成交量高于均值（确认卖压真实）
        vol_ok = dataframe["volume"] > dataframe[vol_col]

        # ── enter_tag：资金费率为正时加标记增加杠杆 ─────────────────
        dataframe["enter_tag"] = "base"
        dataframe.loc[dataframe["funding_rate"] > 0, "enter_tag"] = "fund"

        # ── 主入场 ───────────────────────────────────────────────────
        entry = (
            gate_bear
            & (touched_ema | touched_ema.shift(1))  # 当根或前一根触及
            & rejection
            & rsi_pullback
            & below_ema50
            & macd_neg
            & vol_ok
            & (dataframe["volume"] > 0)
        )

        dataframe.loc[entry, "enter_short"] = 1

        return dataframe

    # ── 出场信号 ────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        rsi_col   = f"rsi_{self.rsi_period.value}"
        ema21_col = f"ema21_{self.ema21_period.value}"

        # RSI 超卖（≤30）或价格重新站上 EMA21（趋势可能反转）
        dataframe.loc[
            (
                (dataframe[rsi_col] <= 30)
                | (dataframe["close"] > dataframe[ema21_col])
            )
            & (dataframe["volume"] > 0),
            "exit_short",
        ] = 1

        return dataframe
