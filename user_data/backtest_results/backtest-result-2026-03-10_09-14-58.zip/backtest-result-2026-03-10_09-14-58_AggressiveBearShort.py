# pragma pylint: disable=missing-docstring, invalid-name
"""
Strategy: AggressiveBearShort
- 五因子加权评分系统，专为熊市10日极速收益设计
- 因子：短期动量 + 资金费率拥挤 + ATR冲击 + 放量破位 + MACD翻转
- 动态杠杆：评分越高杠杆越大（3x / 5x / 7x）
- 快进快出：ROI 3%，trailing stop 1%
"""

import numpy as np
import pandas as pd
from pandas import DataFrame

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, informative
from freqtrade.enums import CandleType
import talib.abstract as ta
from technical import qtpylib


class AggressiveBearShort(IStrategy):

    INTERFACE_VERSION: int = 3
    can_short: bool = True
    timeframe = "1h"

    # 快速止盈：3% 锁定，不等大波段
    minimal_roi = {
        "0":   0.03,
        "120": 0.02,
        "240": 0.01,
    }

    stoploss = -0.02

    # 盈利 1.5% 后启动追踪，回撤 1% 出场
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    process_only_new_candles = True
    startup_candle_count: int = 220

    use_exit_signal = True
    exit_profit_only = True      # 只在盈利时才考虑 exit_signal，亏损靠 stoploss
    ignore_roi_if_entry_signal = False

    # ── 超参数 ──────────────────────────────────────────────────────
    atr_period     = IntParameter(7, 21,  default=14, space="sell", optimize=True, load=True)
    atr_sma_period = IntParameter(20, 50, default=30, space="sell", optimize=True, load=True)
    atr_spike_mult = DecimalParameter(1.2, 2.0, decimals=1, default=1.5, space="sell", optimize=True, load=True)
    vol_sma_period = IntParameter(10, 30, default=20, space="sell", optimize=True, load=True)
    rsi_period     = IntParameter(7, 21,  default=14, space="sell", optimize=True, load=True)
    mom_bars       = IntParameter(3, 10,  default=5,  space="sell", optimize=True, load=True)
    score_threshold = IntParameter(55, 85, default=60, space="sell", optimize=True, load=True)

    # ── 4h 宏观门控 ─────────────────────────────────────────────────
    @informative("4h")
    def populate_indicators_4h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["ema50"]  = ta.EMA(dataframe, timeperiod=50)
        dataframe["ema200"] = ta.EMA(dataframe, timeperiod=200)
        return dataframe

    # ── 1h 主指标 ───────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        # RSI
        for val in self.rsi_period.range:
            dataframe[f"rsi_{val}"] = ta.RSI(dataframe, timeperiod=val)

        # ATR
        for val in self.atr_period.range:
            dataframe[f"atr_{val}"] = ta.ATR(dataframe, timeperiod=val)
        for val in self.atr_sma_period.range:
            dataframe[f"atr_sma_{val}"] = ta.SMA(
                dataframe[f"atr_{self.atr_period.value}"], timeperiod=val
            ) if f"atr_{self.atr_period.value}" in dataframe.columns \
            else ta.SMA(ta.ATR(dataframe, timeperiod=self.atr_period.value), timeperiod=val)

        # Volume SMA
        for val in self.vol_sma_period.range:
            dataframe[f"vol_sma_{val}"] = ta.SMA(dataframe["volume"], timeperiod=val)

        # MACD
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macdhist"] = macd["macdhist"]

        # 短期动量（N根K线累计收益率）
        for val in self.mom_bars.range:
            dataframe[f"mom_ret_{val}"] = dataframe["close"].pct_change(val)

        # 真实资金费率
        funding_df = self.dp.get_pair_dataframe(
            pair=metadata["pair"],
            timeframe=self.timeframe,
            candle_type=CandleType.FUNDING_RATE,
        )
        if funding_df is not None and not funding_df.empty:
            funding_df = funding_df[["date", "open"]].rename(columns={"open": "funding_rate"})
            dataframe = dataframe.merge(funding_df, on="date", how="left")
            dataframe["funding_rate"] = dataframe["funding_rate"].ffill().fillna(0)
        else:
            dataframe["funding_rate"] = 0
        dataframe["funding_rate_mean8"] = dataframe["funding_rate"].rolling(8).mean().fillna(0)

        return dataframe

    # ── 动态杠杆 ────────────────────────────────────────────────────
    def leverage(self, pair, current_time, current_rate, proposed_leverage,
                 max_leverage, entry_tag, side, **kwargs) -> float:
        if entry_tag and "score_90" in entry_tag:
            return min(7.0, max_leverage)
        elif entry_tag and "score_75" in entry_tag:
            return min(5.0, max_leverage)
        return min(3.0, max_leverage)

    # ── 入场信号 ────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        atr_col     = f"atr_{self.atr_period.value}"
        atr_sma_col = f"atr_sma_{self.atr_sma_period.value}"
        vol_col     = f"vol_sma_{self.vol_sma_period.value}"
        rsi_col     = f"rsi_{self.rsi_period.value}"
        mom_col     = f"mom_ret_{self.mom_bars.value}"

        # ── 宏观门控（必须满足）
        macro_bear = dataframe["ema50_4h"] < dataframe["ema200_4h"]

        # ── 五因子评分 ──────────────────────────────────────────────
        # Factor 1: 短期动量偏空（近N根K线累计下跌超1.5%）  权重25
        f1 = (dataframe[mom_col] < -0.015).astype(int) * 25

        # Factor 2: 资金费率拥挤（多头持续付费）           权重25
        f2 = (
            (dataframe["funding_rate"] > 0)
            & (dataframe["funding_rate_mean8"] > 0.0001)
        ).astype(int) * 25

        # Factor 3: ATR波动率冲击（恐慌性抛售）            权重20
        f3 = (
            dataframe[atr_col] > dataframe[atr_sma_col] * self.atr_spike_mult.value
        ).astype(int) * 20

        # Factor 4: 放量阴线破位                          权重15
        breakdown = dataframe["close"] < dataframe["low"].shift(1).rolling(2).min()
        f4 = (
            breakdown
            & (dataframe["volume"] > dataframe[vol_col] * 1.5)
            & (dataframe["close"] < dataframe["open"])
        ).astype(int) * 15

        # Factor 5: MACD hist 从正转负（第1-2根）          权重15
        f5 = (
            (dataframe["macdhist"] < 0)
            & (dataframe["macdhist"].shift(1) >= 0)
        ).astype(int) * 15

        total_score = f1 + f2 + f3 + f4 + f5

        # ── 评分分档，写入 enter_tag 供杠杆回调读取 ────────────────
        dataframe["enter_tag"] = ""
        dataframe.loc[total_score >= 90, "enter_tag"] = "score_90"
        dataframe.loc[(total_score >= 75) & (total_score < 90), "enter_tag"] = "score_75"
        dataframe.loc[(total_score >= self.score_threshold.value) & (total_score < 75), "enter_tag"] = "score_60"

        dataframe.loc[
            macro_bear & (total_score >= self.score_threshold.value),
            "enter_short",
        ] = 1

        return dataframe

    # ── 出场信号 ────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        rsi_col = f"rsi_{self.rsi_period.value}"

        # 只用 RSI 超卖出场（exit_profit_only=True 保护，不会在亏损时乱平）
        dataframe.loc[
            (dataframe[rsi_col] <= 25)
            & (dataframe["volume"] > 0),
            "exit_short",
        ] = 1

        return dataframe
