# pragma pylint: disable=missing-docstring, invalid-name
"""
Strategy: AggressiveBear15m  v4 — 多品种熊市做空
==================================================
v4 核心改进（相比 v3）：
  1. 移除 EMA touch 条件 → 改用熊市对齐 + 阴线确认（信号频率提升 5-10x）
  2. 支持多品种同时开仓（BTC/ETH/SOL/XRP/ADA），通过 config 配置
  3. 杠杆 5x（强熊信号 7x），止损放宽至 5%（避免 15m 噪音触发）
  4. 追踪止盈从 6% 启动，可跑赢大段行情
  5. 目标：两个月熊市 >20% 绝对收益

入场条件：
  1h ：EMA_fast < EMA_slow（中期趋势向下）
  15m：close < EMA21 且 EMA21 < EMA50（空头排列）
  15m：阴线（close < open，实体 > 28% 振幅）
  15m：RSI 在 32-62（未超卖，仍有下行空间）
  15m：MACD 柱状图 < 0
  15m：成交量 > 均量
"""

from datetime import datetime
from typing import Optional
import pandas as pd
from pandas import DataFrame

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, informative
from freqtrade.enums import CandleType
import talib.abstract as ta


class AggressiveBear15m(IStrategy):

    INTERFACE_VERSION: int = 3
    can_short: bool = True
    timeframe = "15m"

    # 高 ROI 门槛，让追踪止盈主导退出，只在极端情况触发 ROI
    minimal_roi = {
        "0":    0.15,   # 15% 仓位收益（5x 杠杆 ≈ 3% 市价波动）
        "240":  0.08,   # 4h 后降至 8%
        "600":  0.04,   # 10h 后降至 4%
        "1200": 0.02,   # 20h 后降至 2%
    }

    stoploss = -0.05                          # 5% 仓位止损（5x ≈ 1% 市价）
    trailing_stop = True
    trailing_stop_positive = 0.025            # 峰值后退 2.5% 触发止盈
    trailing_stop_positive_offset = 0.06      # 利润达 6% 后才启动追踪
    trailing_only_offset_is_reached = True

    process_only_new_candles = True
    startup_candle_count: int = 220

    use_exit_signal = True
    exit_profit_only = True       # 亏损只靠 stoploss，不乱平
    ignore_roi_if_entry_signal = False

    # ── 超参数 ──────────────────────────────────────────────────────
    ema21_period  = IntParameter(15, 30,   default=21,   space="sell", optimize=True, load=True)
    ema50_period  = IntParameter(35, 65,   default=50,   space="sell", optimize=True, load=True)

    rsi_period    = IntParameter(7,  21,   default=14,   space="sell", optimize=True, load=True)
    rsi_lo        = IntParameter(25, 42,   default=32,   space="sell", optimize=True, load=True)
    rsi_hi        = IntParameter(50, 68,   default=62,   space="sell", optimize=True, load=True)

    vol_period    = IntParameter(10, 30,   default=20,   space="sell", optimize=True, load=True)
    body_ratio    = DecimalParameter(0.15, 0.50, decimals=2, default=0.28,
                                     space="sell", optimize=True, load=True)

    gate_ema_fast = IntParameter(15, 25,   default=20,   space="sell", optimize=True, load=True)
    gate_ema_slow = IntParameter(40, 60,   default=50,   space="sell", optimize=True, load=True)

    # ── 1h 门控 ─────────────────────────────────────────────────────
    @informative("1h")
    def populate_indicators_1h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        for val in self.gate_ema_fast.range:
            dataframe[f"ema_fast_{val}"] = ta.EMA(dataframe, timeperiod=val)
        for val in self.gate_ema_slow.range:
            dataframe[f"ema_slow_{val}"] = ta.EMA(dataframe, timeperiod=val)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    # ── 15m 主指标 ──────────────────────────────────────────────────
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        for val in self.ema21_period.range:
            dataframe[f"ema21_{val}"] = ta.EMA(dataframe, timeperiod=val)
        for val in self.ema50_period.range:
            dataframe[f"ema50_{val}"] = ta.EMA(dataframe, timeperiod=val)
        for val in self.rsi_period.range:
            dataframe[f"rsi_{val}"] = ta.RSI(dataframe, timeperiod=val)
        for val in self.vol_period.range:
            dataframe[f"vol_sma_{val}"] = ta.SMA(dataframe["volume"], timeperiod=val)

        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe["macdhist"] = macd["macdhist"]
        dataframe["atr14"]    = ta.ATR(dataframe, timeperiod=14)

        # 资金费率
        funding_df = self.dp.get_pair_dataframe(
            pair=metadata["pair"],
            timeframe="1h",
            candle_type=CandleType.FUNDING_RATE,
        )
        if funding_df is not None and not funding_df.empty:
            funding_df = funding_df[["date", "open"]].rename(columns={"open": "funding_rate"})
            dataframe = dataframe.merge(funding_df, on="date", how="left")
            dataframe["funding_rate"] = dataframe["funding_rate"].ffill().fillna(0)
        else:
            dataframe["funding_rate"] = 0

        return dataframe

    # ── 动态杠杆 ────────────────────────────────────────────────────
    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float,
                 entry_tag: Optional[str], side: str, **kwargs) -> float:
        if entry_tag and "strong" in entry_tag:
            return min(7.0, max_leverage)
        if entry_tag and "fund" in entry_tag:
            return min(6.0, max_leverage)
        return min(5.0, max_leverage)

    # ── 入场信号 ────────────────────────────────────────────────────
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        ema21_col = f"ema21_{self.ema21_period.value}"
        ema50_col = f"ema50_{self.ema50_period.value}"
        rsi_col   = f"rsi_{self.rsi_period.value}"
        vol_col   = f"vol_sma_{self.vol_period.value}"
        gf_col    = f"ema_fast_{self.gate_ema_fast.value}_1h"
        gs_col    = f"ema_slow_{self.gate_ema_slow.value}_1h"

        # ── 1h 门控：中期趋势向下 ────────────────────────────────────
        gate_bear = (
            (dataframe[gf_col] < dataframe[gs_col])
            & (dataframe["rsi_1h"] < 70)
        )

        # ── 15m 空头排列：EMA21 < EMA50，收盘在 EMA21 下 ─────────────
        bear_align = (
            (dataframe["close"] < dataframe[ema21_col])
            & (dataframe[ema21_col] < dataframe[ema50_col])
        )

        # ── 阴线确认：实体占振幅比例 > body_ratio ────────────────────
        body = (dataframe["open"] - dataframe["close"]).clip(lower=0)
        rng  = (dataframe["high"] - dataframe["low"]).clip(lower=1e-8)
        bear_candle = (
            (dataframe["close"] < dataframe["open"])
            & (body > self.body_ratio.value * rng)
        )

        # ── RSI：有下行空间（未超卖） ─────────────────────────────────
        rsi_ok = (
            (dataframe[rsi_col] > self.rsi_lo.value)
            & (dataframe[rsi_col] < self.rsi_hi.value)
        )

        # ── MACD 柱状图为负 ────────────────────────────────────────
        macd_neg = dataframe["macdhist"] < 0

        # ── 成交量高于均值 ─────────────────────────────────────────
        vol_ok = dataframe["volume"] > dataframe[vol_col]

        # ── 强熊信号：连续 3 根收盘价下行 ────────────────────────────
        strong_bear = (
            (dataframe["close"] < dataframe["close"].shift(1))
            & (dataframe["close"].shift(1) < dataframe["close"].shift(2))
            & (dataframe["close"].shift(2) < dataframe["close"].shift(3))
        )

        # ── enter_tag（决定杠杆） ────────────────────────────────────
        dataframe["enter_tag"] = "base"
        dataframe.loc[strong_bear, "enter_tag"] = "strong"
        dataframe.loc[dataframe["funding_rate"] > 0.0001, "enter_tag"] = "fund"
        dataframe.loc[
            strong_bear & (dataframe["funding_rate"] > 0.0001), "enter_tag"
        ] = "strong_fund"

        # ── 主入场 ───────────────────────────────────────────────────
        entry = (
            gate_bear
            & bear_align
            & bear_candle
            & rsi_ok
            & macd_neg
            & vol_ok
            & (dataframe["volume"] > 0)
        )

        dataframe.loc[entry, "enter_short"] = 1
        return dataframe

    # ── 出场信号 ────────────────────────────────────────────────────
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        rsi_col   = f"rsi_{self.rsi_period.value}"
        ema50_col = f"ema50_{self.ema50_period.value}"

        # RSI 深度超卖（≤28）或收盘站回 EMA50（趋势反转）
        dataframe.loc[
            (
                (dataframe[rsi_col] <= 28)
                | (dataframe["close"] > dataframe[ema50_col])
            )
            & (dataframe["volume"] > 0),
            "exit_short",
        ] = 1

        return dataframe
